<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="teacherN.css">
		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
      
</head>
<body>

	<div class="bgimage">
		<div class="menu">
			
			<div class="leftmenu">
				<h4> Something </h4>
			</div>

			<div class="rightmenu">
				<ul>
					<a href="teacherHome.php"><li> HOME </li></a>
					<a href="teacherpass.php"><li> ChangePassword </li></a>
					<a href="teacherRoutin.php"><li> routin</li></a>
					<a href="teacherFiles.php"><li> files</li></a>
					<a href="teacherNotice.php"><li> Notice </li></a>
					<a href="logout.php"><li>Logout</li></a>
				</ul>
			</div>
            		<div class="tbl2">
                        
                        
                         <form action="upload.php" method="POST" enctype="multipart/form-data">
                             <p><font color=red>*</font>Insert File Name</p>
                        <input type="text" name="nameFile">
                        <input type="file" name="file">
                        <input type="submit" name="submit2">
                        </form>
                        
                       <?php
                             session_start(); //start the PHP_session function 

                      $u=$_SESSION['a'][0];
                      
                      
                            

                            $files=scandir("uploads");
                        
                        for($a=2;$a<count($files);$a++)
                            
                        {
                            
                            ?>
                            <a style="color:white" download="<?php echo $files[$a] ?>" href="uploads/<?php echo $files[$a] ?>"><br><br><?php echo $files[$a]  ?></a>
                            <?php
                        }
                    ?>
                           
                        
                        
                    </div>
        
        </div>


		

		
		</div>

	

</body>
</html>