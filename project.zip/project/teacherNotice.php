<?php

 
   if(isset($_POST['submitNotice']))
   {
       if(empty($_POST['notice']))
        {
            
            ?>
            <script>
                
                alert("A Notice name is required");
                
            </script>
            <?php
            
        }
       elseif(empty($_POST['teacherName']))
       {
           ?>
            <script>
                
                alert("A name is required");
                
            </script>
            <?php
       }
       else
       {
                            require 'config.php';
                            session_start(); //start the PHP_session function 

                            
                            $u=$_SESSION['a'][0];
                             $notice=$_POST['notice'];
                            $name=$_POST['teacherName'];
          
                            $statement="insert into notice(id, name, notice) VALUES ('$u','$name','$notice')";
                            $result = mysqli_query($conn, $statement);
                            
                            mysqli_close($conn);
           
       }
   }
    
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="teacherN.css">
		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
      
</head>
<body>

	<div class="bgimage">
		<div class="menu">
			
			<div class="leftmenu">
				<h4> Something </h4>
			</div>

			<div class="rightmenu">
				<ul>
					<a href="teacherHome.php"><li> HOME </li></a>
					<a href="teacherpass.php"><li> ChangePassword </li></a>
					<a href="teacherRoutin.php"><li> routin</li></a>
					<a href="teacherFiles.php"><li> files</li></a>
					<a href="teacherNotice.php"><li> Notice </li></a>
					<a href="logout.php"><li>Logout</li></a>
				</ul>
			</div>
            		<div class="tbl2">
                        <form action="teacherNotice.php" method="POST">
                            <p>Name:</p>
                            <input type="text" name="teacherName">
                            <p>Notice:</p>
                            <input type="text" name="notice">
                            <input type="submit" name="submitNotice">
                        
                        
                        
                      
                        </form>  
                        
                         
                        
                        
                    </div>
        
        </div>


		

		
		</div>

	

</body>
</html>