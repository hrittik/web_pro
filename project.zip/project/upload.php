<?php
    if(isset($_POST['submit2']))
    {
        if(empty($_POST['nameFile']))
        {
            
            ?>
            <script>
                
                alert("A File name is required");
                
            </script>
            <?php
            
        }
        else
        {
        $file=$_FILES['file'];
        session_start();
        $_SESSION['comment']=$_POST['comment'];
        
        
        $fileName=$_FILES['file']['name'];
        $fileTmpName=$_FILES['file']['tmp_name'];
        $fileSize=$_FILES['file']['size'];
        $fileError=$_FILES['file']['error'];
        $fileType=$_FILES['file']['type'];
        
        $fileExt=explode('.',$fileName);
        $fileActualExt= strtolower(end($fileExt));
        
        $allowed=array('jpg','jpeg','png','png','txt','pdf','doc');
        
        if(in_array($fileActualExt,$allowed))
        {
            if($fileError===0)
            {
                if($fileSize<5000000)
                {
                    
					
					   $fileNameNew=$_POST['nameFile'].".".$fileActualExt;
                        
						$fileDestination='uploads/'.$fileNameNew;
						move_uploaded_file($fileTmpName,$fileDestination);
						header("Location:teacherFiles.php? uploadsuccess");
                        
                   
                        
                        
					
                }
                else
                {
                    echo "The file is too large";
                }
                
                
            }
            else
            {
                echo "there was an error";
                
            }
            
            
        }
        else
        {
            echo "You cannot upload this type of file";
        }
         
        
        
    }
    }



?>