
</<!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<from action="admin_student_add.php" method="POST">
 		<input type="text" name="Name"  size=100 required pattern=""> 
 		<input type="submit" name="submit">
    

 	</from>
 </body>