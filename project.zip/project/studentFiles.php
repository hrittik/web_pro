<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="teacherN.css">
		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
</head>
<body>

	<div class="bgimage">
		<div class="menu">
			
			<div class="leftmenu">
				<h4> Something </h4>
			</div>

			<div class="rightmenu">
				<ul>
					<a href="studentHome.php"><li> HOME </li></a>
					<a href="studentPass.php"><li> ChangePassword </li></a>
					<a href="studentRoutin.php"><li> routin</li></a>
					<a href="studentFiles.php"><li> files</li></a>
					<a href="studentNotice.php"><li> Notice </li></a>
					<a href="logout.php"><li>Logout</li></a>
				</ul>
			</div>
            
            <div class="tbl2">
                <p>Download Your Files From The links Below</p>
                <?php
                        
                      
                            

                            $files=scandir("uploads");
                        
                        for($a=2;$a<count($files);$a++)
                            
                        {
                            
                            ?>
                            <a style="color:white" download="<?php echo $files[$a] ?>" href="uploads/<?php echo $files[$a] ?>"><br><br><?php echo $files[$a]  ?></a>
                            <?php
                        }
                    ?>
                        
                        
                       
                        
                      
                        
            </div>

		</div>

		

	</div>

</body>
</html>