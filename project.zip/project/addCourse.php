<?php
$error=0;
$usernameInval="";
$usernameInval1="";
$usernameInval2="";
$usernameInval3="";
$usernameInval4="";
$usernameInval5="";
$usernameInval6="";
$user="";
$sts="";


 if(isset($_POST['addteacher'])){
                
            $user=$_POST['tid'];
            $usernm=$_POST['tname'];
            $userem=$_POST['temail'];
            $userph=$_POST['tphone'];
            $useraddr=$_POST['taddress'];
            $userpass=$_POST['tpass'];
         
        
            
           if(empty($user)){
            $usernameInval1="require ";
            $error++;
            }
            if($user)
            {
                $user=test_input($user);

                if (!preg_match("/^[a-zA-Z]*$/",$user))
                 {
                   $usernameInval1 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
             if(empty($usernm)){
            $usernameInval2="require ";
            $error++;
            }
            if($usernm)
            {
                $usernm=test_input($usernm);

                if (!preg_match("/^[a-zA-Z]*$/",$usernm))
                 {
                   $usernameInval2 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if(empty($userph)){
            $usernameInval4="require ";
            $error++;
            }
            if($userph)
            {
                $userph=test_input($userph);

                if (!preg_match("/^[0-9]*$/",$userph))
                 {
                   $usernameInval4 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if(empty($useraddr)){
            $usernameInval5="require";
            $error++;
            }
            if($useraddr)
            {
                $useraddr=test_input($useraddr);

                if (!preg_match("/^[a-zA-Z,0-9]*$/",$useraddr))
                 {
                   $usernameInval5 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if(empty($userem)){
            $usernameInval3="require ";
            $error++;
            }
            
            if(empty($userpass)){
            $usernameInval6="require ";
            $error++;
            }
           
            if($error==0)

            {
                    
                    require 'config.php';

                     $statement= "select * from teacherinfo where id='$user'";
                     $result = mysqli_query($conn, $statement);

                    if (mysqli_num_rows($result) > 0)
                    {
                        
                            $sts= "ID already exist";

                    }
                    elseif(!mysqli_num_rows($result) > 0)
                    {

                        $statement1="insert into teacherinfo (id,name,phone,email,address) values ('$user','$usernm','$userph','$$useraddr') ";
                        $statement2="insert into logintable (id,password,type) values ('$user','$userpass','2') ";

                        $result1 = mysqli_query($conn, $statement1);
                        $result2 = mysqli_query($conn, $statement2);
                        if($result1&&$result1){
                            $sts="ADDED";


                        }
                        else{

                            $sts="ADDED  Fail";
                        }


                    }
                    




            }
 }


 if(isset($_POST['upteacher'])){
                
            $user=$_POST['tid'];
            $usernm=$_POST['tname'];
            $userem=$_POST['temail'];
            $userph=$_POST['tphone'];
            $useraddr=$_POST['taddress'];
         
        
            
           if(empty($user)){
            $usernameInval1="require ";
            $error++;
            }
            if($user)
            {
                $user=test_input($user);

                if (!preg_match("/^[a-zA-Z0-9]*$/",$user))
                 {
                   $usernameInval1 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
             if(empty($usernm)){
            $usernameInval2="require ";
            $error++;
            }
            if($usernm)
            {
                $usernm=test_input($usernm);

                if (!preg_match("/^[a-zA-Z]*$/",$usernm))
                 {
                   $usernameInval2 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if(empty($userph)){
            $usernameInval4="require ";
            $error++;
            }
            if($userph)
            {
                $userph=test_input($userph);

                if (!preg_match("/^[0-9]*$/",$userph))
                 {
                   $usernameInval4 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if(empty($useraddr)){
            $usernameInval5="require";
            $error++;
            }
            if($useraddr)
            {
                $useraddr=test_input($useraddr);

                if (!preg_match("/^[a-zA-Z,0-9]*$/",$useraddr))
                 {
                   $usernameInval5 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if(empty($userem)){
            $usernameInval3="require ";
            $error++;
            }
            if($userem)
            {
                $userem=test_input($userem);
                $v = "/[a-zA-z0-9.-]+\@[a-zA-z0-9.-]+.[a-zA-Z]+/";

                if (!preg_match($v,$userem))
                 {
                   $usernameInval3 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if($error==0)

            {
                    
                    require 'config.php';

                    $statement= "update teacherinfo set name ='$usernm', phone='$userph',email='$userem', address='$useraddr' WHERE id='$user'";
                    
                    $result = mysqli_query($conn, $statement);
                    if ($result)
                    {
                        $sts="UPDATED";

                    }
                    else{

                        $sts="Update Fail";
                    }




            }
        }


 if(isset($_POST['delteacher'])){
                
         $user=$_POST['tid'];
         
        
            
           if(empty($user)){
            $usernameInval1="Invalid ";
            $error++;
            }
            if($user)
            {
                $user=test_input($user);

                if (!preg_match("/^[a-zA-Z0-9]*$/",$user))
                 {
                   $usernameInval1 = "Only letters and number-  allowed"; 
                   $error++;
                }
            }
            if($error==0)

            {
                    
                    require 'config.php';

                    $statement= " delete from `teacherinfo` WHERE id='$user' ";
                     $statement2= " delete from `logintable` WHERE id='$user' AND type=2 ";
                    $result = mysqli_query($conn, $statement);
                    $result2 = mysqli_query($conn, $statement2);
                    if($result&&$result2)
                    {
                        $sts="DELETED";
                    }
                    else
                    {
                        $sts="fail";
                    }




            }

        
        }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="admin_student.CSS">
         <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
          <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
</head>
<body>

    <div class="bgimage">

        <div class="menu">
            
            <div class="leftmenu">
                <h4> Something </h4>
            </div>

            <div class="rightmenu">
                <ul>
                    <a href="Admin_dashboard.php"><li> HOME </li></a>
                    <a href="adminpass.php"><li> ChangePassword </li></a>
                    <a href="adminstudent.php"><li> Student</li></a>
                    <a href="teacheradmin.php"><li> Teacher</li></a>
                    <a href="addCourse.php"><li> Course </li></a>
                    <a href="logout.php"><li>Logout</li></a>
                </ul>
            </div>

        </div>
        
        <div class="tbl3">
        <form method="POST"   >
            
            <table border="0px" style="margin-left: 35%">
        <tr>
          <td colspan="3">
            <h4 style="color: red;text-align: center;
                      font-size: 22px;  "> ----Teacher CRUD---- </h4>
                     
         
            
          </td>
        </tr>
      
      
                <tr>
          <td colspan="3">
            <h4 style="color: red;text-align: center;
                      font-size: 22px; text-transform: uppercase; "> </h4>
                     
          </td>
          
          
        </tr>
        </table>
      

        <table border="0px">
        <tr>
                    <td>
                        <div class="text">
                            <ul>
                                <li> <h4> ID </h4> </li>
                               
                            </ul>

                        </div>
                    </td>
                    <td >
                        <div class="text"> 
                            <ul>
                               
                                <li> <h4><input type="text" name="tid"></h4> </li>
                                <p><?php echo $usernameInval1;?></p>

                             </ul>
                        </div>
                        
                    </td>
                    <td>
                         <div class="text">
                            <ul>
                               
                                <input type="submit" name="addteacher" value="ADD">

                             </ul>
                        </div>
                      
                    </td>
        </tr>  
         <tr>
                    <td>
                        <div class="text">
                            <ul>
                                <li> <h4> Name </h4> </li>
                               
                            </ul>

                        </div>
                    </td>
                    <td width="5px">
                        <div class="text">
                            <ul>
                               
                                <li> <h4><input type="text" name="tname"  ></h4> </li>
                                <p><?php echo $usernameInval2;?></p>

                             </ul>
                        </div>
                        
                    </td>
                    <td>
                         <div class="text">
                            <ul>
                               
                                <input type="submit" name="upteacher" value="UPDATE">

                             </ul>
                        </div>
                      
                    </td>
        </tr>  
        <tr>
                    <td>
                        <div class="text">
                            <ul>
                                <li> <h4> Email </h4> </li>
                               
                            </ul>

                        </div>
                    </td>
                    <td width="5px">
                        <div class="text">
                            <ul>
                               
                                <li> <select name="temail">
                                        <option value="SUN">SUN</option>
                                        <option value="MON">MON</option>
                                         <option value="TUE">TUE</option>
                                         <option value="WED">WED</option>
                                         <option value="THU">THU</option>
                                    </select></h4> </li>
                                <p><?php echo $usernameInval3;?></p>

                             </ul>
                        </div>
                        
                    </td>
                     <td>
                         <div class="text">
                            <ul>
                               
                                <input type="submit" name="delteacher" value="DELETE">

                             </ul>
                        </div>
                      
                    </td>
        </tr> 
        <tr>
                    <td>
                        <div class="text">
                            <ul>
                                <li> <h4> Phone </h4> </li>
                               
                            </ul>

                        </div>
                    </td>
                    <td width="5px">
                        <div class="text">
                            <ul>
                               
                                <li> <h4><input type="text" name="tphone"></h4> </li>
                                <p><?php echo $usernameInval4;?></p>

                             </ul>
                        </div>
                        
                    </td>
                     <td>
                         <div class="text">
                            <ul>
                               
                                <li><h4><?php echo $sts;?></h4></li>

                             </ul>
                        </div>
                      
                    </td>
        </tr>
        <tr>
                    <td>
                        <div class="text">
                            <ul>
                                <li> <h4> Address </h4> </li>
                               
                            </ul>

                        </div>
                    </td>
                    <td width="5px">
                        <div class="text">
                            <ul>
                               
                                <li> <h4><input type="text" name="taddress"></h4> </li>
                                <p><?php echo $usernameInval5;?></p>

                             </ul>
                        </div>
                        
                    </td>
        </tr> 
        <tr>
                    <td>
                        <div class="text">
                            <ul>
                                <li> <h4> PASSWORD </h4> </li>
                               
                            </ul>

                        </div>
                    </td>
                    <td >
                        <div class="text">
                            <ul>
                               
                               

                             </ul>
                        </div>
                        
                    </td>
                    
             </tr>            
                   
               
            </table>
        </form>
        
        </div>
        
        
    </div>

</body>
</html>