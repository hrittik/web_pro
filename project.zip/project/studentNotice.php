
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="teacherN.css">
		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
      
</head>
<body>

	<div class="bgimage">
		<div class="menu">
			
			<div class="leftmenu">
				<h4> Something </h4>
			</div>

			<div class="rightmenu">
				<ul>
					<a href="studentHome.php"><li> HOME </li></a>
					<a href="studentpass.php"><li> ChangePassword </li></a>
					<a href="studentRoutin.php"><li> routin</li></a>
					<a href="studentFiles.php"><li> files</li></a>
					<a href="studentNotice.php"><li> Notice </li></a>
					<a href="logout.php"><li>Logout</li></a>
				</ul>
			</div>
            		<div class="tbl2">
                       <form method="POST"> 
                       <table border=1>
                          <tr>
                            <td width=300px><p>Id</p></td>
                            <td width=300px><p>Name</p></td>
                            <td width=300px><p>Notice</p></td>
                            
                          </tr>
                          <tr>
                            <td width=300px><?php


                      require 'config.php';
                           session_start(); //start the PHP_session function 

                      $u=$_SESSION['a'][0];
                      
                      
                              $statement="select * from notice";
                            $result = mysqli_query($conn, $statement);
                            if (mysqli_num_rows($result) > 0)
                              { 
                                  while($row = mysqli_fetch_assoc($result))
                                    {
                                      ?>  
                                         <p><?php echo $row['id']?></p>
                                         <?php
                                         
                                        }
                            }     
                            else
                              {
                                  echo "INVALID";
                              }
                            mysqli_close($conn);
                         
       
   
    
?></td>
<td width=300px><?php


                      require 'config.php';
                           //start the PHP_session function 

                      $u=$_SESSION['a'][0];
                      
                      
                              $statement="select * from notice";
                            $result = mysqli_query($conn, $statement);
                            if (mysqli_num_rows($result) > 0)
                              { 
                                  while($row = mysqli_fetch_assoc($result))
                                    {
                                      ?>  
                                         <p><?php echo $row['name']?></p>
                                         <?php
                                         
                                        }
                            }     
                            else
                              {
                                  echo "INVALID";
                              }
                            mysqli_close($conn);
                         
       
   
    
?></td><td width=300px><?php


                      require 'config.php';
                            //start the PHP_session function 

                      $u=$_SESSION['a'][0];
                      
                      
                              $statement="select * from notice";
                            $result = mysqli_query($conn, $statement);
                            if (mysqli_num_rows($result) > 0)
                              { 
                                  while($row = mysqli_fetch_assoc($result))
                                    {
                                      ?>  
                                         <p><?php echo $row['notice']?></p>
                                         <?php
                                         
                                        }
                            }     
                            else
                              {
                                  echo "INVALID";
                              }
                            mysqli_close($conn);
                         
       
   
    
?></td>
                            
                          </tr>
                       </table>
                     </form>
                        
                        
                      
                        
                        
                         
                        
                        
                    </div>
        
        </div>


		

		
		</div>

	

</body>
</html>